import React, { Component } from "react";
import AdminService from "./../../services/adminService";

class AllUserList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      UserList: [{ UserId: "", UserName: "", EmailId: "", RoleId: "" }]
    };
    this.serv = new AdminService();
  }

  
  getSelected(p) {
    // this.setState({ UserId: p.UserId });
  }

  componentDidMount() {
    this.serv
      .getAllList()
      .then(res => res.json())
      .then(resp => {
        this.setState({ UserList: resp.data });
      })
      .catch(error => console.log(error.status));
  }
  render() {
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">All Users </h3>
        <div className="container">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div className="col-md-12">
                <form id="login-form" className="">
                  <h3 className="text-center text-info">All Users</h3>
                  <div className="row">
                    <table className=" table table-bordered table-striped">
                      <thead>
                        <tr>
                          <td>UserId</td>
                          <td>UserName</td>
                          <td>EmailId</td>
                          <td>Role</td>
                          <td>
                            AddPersonInformation</td>
                        </tr>
                      </thead>
                      <tbody>
                        {this.state.UserList.map((prd, idx) => (
                          <TableRow
                            key={idx}
                            row={prd}
                            // selected={this.getSelected.bind(this)}
                          />
                        ))}
                        
                      </tbody>
                    </table>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

class TableRow extends Component {
    constructor(props) {
      super(props);
    }
  //   onRowClick() {
  //     // alert(`Row Clicked ${JSON.stringify(this.props.row)}`);
  //     this.props.selected(this.props.row);
  //   }

  addPersnInfo = () => {
    const h = this.props.history;
    console.log(this.props);

console.log(this.props.history);
   h.push("/updateUserAccessData");
  }

  render() {

    let roleName = null;
    if(this.props.row.RoleId === 1)
    {
        roleName = "Admin"
    }if(this.props.row.RoleId === 2){
        roleName = "User"
    }if(this.props.row.RoleId === 3){
        roleName = "Operator"
    }
      
    return (
        
      <tr>
        <td>{this.props.row.UserId}</td>
        <td>{this.props.row.UserName}</td>
        <td>{this.props.row.EmailId}</td>
        <td>{roleName}</td>
        <td>
        
          <input
            type="button"
            value="AddPersonInformation"
            onClick={this.addPersnInfo}
            className="btn btn-info btn-md"
          />
        </td>
      </tr>
    );
  }
}

export default AllUserList;
