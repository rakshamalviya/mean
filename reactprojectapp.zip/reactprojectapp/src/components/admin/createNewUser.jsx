import React, { Component } from "react";
import AdminService from "./../../services/adminService";
class CreateNewUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      UserId: "",
      UserName: "",
      EmailId: "",
      Password: "",
      RoleId: ""
    };
    this.serv = new AdminService();
  }
  addPersnInfo(e) {
    const h = this.props.history;

    h.push("/allUserList");
  }

  putValue = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  createNewUser(e) {
    let userData = {
      UserId: this.state.UserId,
      UserName: this.state.UserName,
      EmailId: this.state.EmailId,
      Password: this.state.Password,
      RoleId: this.state.RoleId
    };

    console.log(JSON.stringify(userData));

    this.serv
      .saveNewUserData(userData)
      .then(res => res.json())
      .then(resp => {
        console.log("in response, Status is===" + resp.status);
        if (resp.status === 200) {
          alert("New User Created Successfully");
        }
      })
      .catch(error => console.log(error.status));
  }

  render() {
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">User Registration Form</h3>
        <div className="form">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
                <form id="login-form" className="form" method="post">
                  <h3 className="text-center text-info">Create New User</h3>
                  <div className="col-sm-12">
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">UserId</label>
                        <input
                          type="text"
                          className="form-control"
                          name="UserId"
                          onChange={this.putValue.bind(this)}
                          required
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">UserName</label>
                        <input
                          type="text"
                          className="form-control"
                          name="UserName"
                          onChange={this.putValue.bind(this)}
                          required
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">Email</label>
                        <input
                          type="text"
                          className="form-control"
                          name="EmailId"
                          onChange={this.putValue.bind(this)}
                          required
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">Password</label>
                        <input
                          type="password"
                          className="form-control"
                          name="Password"
                          onChange={this.putValue.bind(this)}
                          required
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">Role</label>
                        <select
                          className="form-control text-info"
                          name="RoleId"
                          onChange={this.putValue.bind(this)}
                        >
                          <option>Select</option>
                          <option value="1">Admin</option>
                          <option value="2">User</option>
                          <option value="3">Operator</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-sm-4">
                      <input
                        type="button"
                        value="Save"
                        onClick={this.createNewUser.bind(this)}
                        className="btn btn-info btn-md"
                      />
                    </div>
                    <div className="col-sm-4">
                      <input
                        type="button"
                        value="Cancel"
                        className="btn btn-danger"
                      />
                    </div>
                    <div className="col-sm-4">
                      <input
                        type="button"
                        value="AddPersonInfo"
                        onClick={this.addPersnInfo.bind(this)}
                        className="btn btn-info btn-md"
                      />
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateNewUser;
