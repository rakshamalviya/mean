import React, { Component } from 'react'


class TableRow extends Component {
      constructor(props) {
        super(props);
      }


      addPersnInfo(e) {
        const h = this.props.history;
    
        h.push("/updateUserAccessData");
      }


   
    render() {
  
      let roleName = null;
      if(this.props.row.RoleId === 1)
      {
          roleName = "Admin"
      }if(this.props.row.RoleId === 2){
          roleName = "User"
      }if(this.props.row.RoleId === 3){
          roleName = "Operator"
      }
        
      return (
          
        <tr>
          <td>{this.props.row.UserId}</td>
          <td>{this.props.row.UserName}</td>
          <td>{this.props.row.EmailId}</td>
          <td>{roleName}</td>
          <td>
          
            <input
              type="button"
              value="AddPersonInformation"
              onClick={this.props.addPersnInfo.bind(this)}
              className="btn btn-info btn-md"
            />
          </td>
        </tr>
      );
    }
  }
  export default TableRow;