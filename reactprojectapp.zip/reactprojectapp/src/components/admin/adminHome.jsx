import React, { Component } from "react";

class AdminHome extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  createUser(e){
  const h = this.props.history;

    h.push('/createNewUser');
  }

  render() {
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">Admin Home</h3>
        <div className="container">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div className="col-md-12">
                <form id="login-form" className="">
                  <h3 className="text-center text-info">Admin Home</h3>

                  <div className="form-group">
                    <input
                      type="button"
                      value="CreateNewUser"
                      onClick={this.createUser.bind(this)}
                      className="btn btn-info btn-md"
                    />
                  </div>

                  <div className="row">
                    <table className=" table table-bordered table-striped">
                      <tr>
                        <td>SR.No</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>
                          <input
                            type="button"
                            value="Approve"
                            className="btn btn-info btn-md"
                          />
                        </td>
                        <td>
                          <input
                            type="button"
                            value="Reject"
                            className="btn btn-danger"
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>SR.No</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>
                          <input
                            type="button"
                            value="Approve"
                            className="btn btn-info btn-md"
                          />
                        </td>
                        <td>
                          <input
                            type="button"
                            value="Reject"
                            className="btn btn-danger"
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>SR.No</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>Name</td>
                        <td>
                          <input
                            type="button"
                            value="Approve"
                            className="btn btn-info btn-md"
                          />
                        </td>
                        <td>
                          <input
                            type="button"
                            value="Reject"
                            className="btn btn-danger"
                          />
                        </td>
                      </tr>
                    </table>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default AdminHome;
