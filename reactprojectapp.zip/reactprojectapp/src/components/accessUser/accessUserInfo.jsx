import React, { Component } from "react";
import "./../../css/design.css";
import AccessUserService from "./../../services/accessUserService.js";

class AccessUserInformation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      PersonalUniqueId: 0,
      FirstName: "",
      MiddleName: "",
      LastName: "",
      Gender: "",
      DOB: "",
      Age: 0,
      Address: "",
      City: "",
      State: "",
      Pincode: 0,
      PhoneNo: 0,
      MobileNo: 0,
      PhysicalDisability: "",
      MaritalStatus: "",
      EducationalStatus: "",
      BirthSign: ""
    };

    var roleid = sessionStorage.getItem("roleid");
    console.log("roleid is ===" + roleid);

    this.accessuserserv = new AccessUserService();
  }
  onClickUpdate = () => {
    const h = this.props.history;
    h.push("/updateUserAccessData");
  };

  componentDidMount() {
    // let userdata = this.accessuserserv.getData()
    //   .then(data => data.json())
    //   .then(value => {
    //     console.log(JSON.stringify(value.data));
    //     // this.setState({ Products: value.data });
    //   })
    //   .catch(error => {
    //     console.log(`Error Occured ${error.status}`);
    //   });
  }
  render() {
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">My Information</h3>
        <div className="form">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
                <form id="login-form" className="form" action="" method="post">
                  <h3 className="text-center text-info">My Information</h3>
                  <table className="form-group">
                    <tr>
                      <td>
                        <strong>
                          <h5>Personal Unique Id </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.PersonalUniqueId}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>Full Name </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>
                          :
                          {`${this.state.FirstName} ${this.state.MiddleName} ${
                            this.state.LastName
                          }`}
                        </h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>Gender </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.Gender}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>DOB </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.DOB}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>Age </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.Age}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>Address </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.Address}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>City </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.City}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>State </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.State}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>PinCode </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.Pincode}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>PhoneNo </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.PhoneNo}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>MobileNo </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.MobileNo}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>PhysicalDisability </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.PhysicalDisability}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>MaritalStatus </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.MaritalStatus}</h5>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          <h5>BirthSign </h5>
                        </strong>
                      </td>
                      <td>
                        <h5>: {this.state.BirthSign}</h5>
                      </td>
                    </tr>
                  </table>
                  <div className="form-group">
                    <input
                      type="submit"
                      name="Update"
                      className="btn btn-info btn-md"
                      onClick={this.onClickUpdate}
                      value="Update"
                    />
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default AccessUserInformation;
