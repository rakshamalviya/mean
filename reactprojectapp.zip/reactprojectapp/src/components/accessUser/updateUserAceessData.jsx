import "./../../css/design.css";
import React, { Component } from "react";

class UpdateUserAccessData extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">User Registration Form</h3>
        <div className="form">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
                <form id="login-form" className="form" method="post">
                  <h3 className="text-center text-info">My Information</h3>
                  <div className="col-sm-12">
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">PersonalUniqueId</label>
                        <input type="text" className="form-control" required />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-4 form-group">
                        <label className="text-info">First Name</label>
                        <input type="text" className="form-control" required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">Middle Name</label>
                        <input type="text" className="form-control" required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">Last Name</label>
                        <input type="text" className="form-control" required />
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="control-label col-sm-3 text-info">
                        Gender
                      </label>
                      <div className="col-sm-6">
                        <div className="row">
                          <div className="col-sm-4">
                            <label className="text-info">
                              <input
                                type="radio"
                                id="femaleRadio"
                                value="Female"
                              />
                              Female
                            </label>
                          </div>
                          <div className="col-sm-4">
                            <label className="text-info">
                              <input type="radio" id="maleRadio" value="Male" />
                              Male
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">DOB</label>
                        <input
                          type="date"
                          className="form-control text-info"
                          required
                        />
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Age</label>
                        <input type="text" className="form-control" required />
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="text-info">Address</label>
                      <textarea rows="3" className="form-control" required />
                    </div>
                    <div className="row">
                      <div className="col-sm-4 form-group">
                        <label className="text-info">City</label>
                        <input type="text" className="form-control" required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">State</label>
                        <input type="text" className="form-control" required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">PinCode</label>
                        <input type="text" className="form-control" required />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">PhoneNo</label>
                        <input type="text" className="form-control" required />
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Mobile</label>
                        <input type="text" className="form-control" required />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">PhysicalDisability</label>
                        <select className="form-control text-info">
                          <option>yes</option>
                          <option>no</option>
                        </select>
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Marital Status</label>
                        <select className="form-control text-info">
                          <option>Married</option>
                          <option>UnMarried</option>
                          <option>Divorced</option>
                          <option>Widow</option>
                          <option>Widowed</option>
                        </select>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Educational Status</label>
                        <select className="form-control text-info">
                          <option>Masters</option>
                          <option>Graduate</option>
                          <option>UnderGraduate</option>
                          <option>SSC</option>
                          <option>HSC</option>
                          <option>phD</option>
                          <option>illiterate</option>
                        </select>
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Birth Sign</label>
                        <input type="text" className="form-control" required />
                      </div>
                      <div className="row">
                        <div className="col-sm-4">
                          <input
                            type="button"
                            value="Save"
                            className="btn btn-info btn-md"
                          />
                        </div>
                        <div className="col-sm-4">
                          <input
                            type="button"
                            value="Update"
                            className="btn btn-info btn-md"
                          />
                        </div>
                        <div className="col-sm-4">
                          <input
                            type="button"
                            value="Cancel"
                            className="btn btn-danger"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default UpdateUserAccessData;
