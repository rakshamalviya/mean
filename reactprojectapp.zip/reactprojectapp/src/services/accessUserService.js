class AccessUserService {
    getData() {
      let promise = fetch("http://localhost:4070/api/personinfo");
      return promise;
    }
  
    postData(prd) {
      let promise = fetch("http://localhost:4070/api/Products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(prd)
      });
      return promise;
    }
  
    deleteData(id) {
      let promise = fetch(`http://localhost:4070/api/Products/${id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        }
      });
      return promise;
    }
    updateData(updtdprd){
        let id = updtdprd.ProductId;
  
      let promise = fetch(`http://localhost:4070/api/Products/${id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(updtdprd)
        });
        return promise;
    }
    // getDataById(id) {
    //     let promise = fetch(`http://localhost:4070/api/personinfo/${id}`, {
    //       method: "GET",
    //       headers: {
    //         "Content-Type": "application/json"
    //       }
    //     });
    //     return promise;
    //   }
  }
  
  export default AccessUserService;
  