class AdminService {
  saveNewUserData(userData) {
    console.log("in admin service");
    let promise = fetch("http://localhost:4070/api/userData", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(userData)
    });
    return promise;
  }

  getAllList() {
    let promise = fetch("http://localhost:4070/api/getUserDetails", {
      method: "GET"
    });
    return promise;
  }
}

export default AdminService;
