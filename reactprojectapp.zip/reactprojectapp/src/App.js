import React, { Component } from 'react';
import LoginPage from "./components/login/loginPage.jsx";
import AccessUserInformation from './components/accessUser/accessUserInfo.jsx';
import UpdateUserAccessData from './components/accessUser/updateUserAceessData.jsx';
import AdminHome from './components/admin/adminHome';
import CreateNewUser from './components/admin/createNewUser';
import AllUserList from './components/admin/allUserList';
import { Router, Switch, Route } from 'react-router-dom';
import { createBrowserHistory } from 'history';

const history = createBrowserHistory();
class App extends Component {
  render() {
    return (
      
      <div>
 <Router history={history}>

           <Switch>
           <Route exact path='/' component={LoginPage}/>
           <Route  path='/accessUserInfo' component={AccessUserInformation}/>
            <Route path='/updateUserAccessData' component={UpdateUserAccessData}/>
            <Route path='/createNewUser' component={CreateNewUser}/>
            <Route path='/adminHome' component={AdminHome}/>
            <Route path='/allUserList' component={AllUserList}/>
             
           </Switch>

         </Router>

      </div>
    );
  }
}

export default App;
