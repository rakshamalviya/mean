var mongoose = require("mongoose");
//1e. set the global promise to manage all asyncalls made by appl using mongoose driver
mongoose.Promise = global.Promise;

const iplocation = require("iplocation").default;
var requestIp = require('request-ip');
//var geolocation = require('geolocation');
const dns = require('dns');
const navigator = global.navigator = {onLine: false};

var getIP = require('ipware')().get_ip;


const AutoIncrement = require("mongoose-sequence")(mongoose);

var loginSchema = mongoose.Schema({
    LoginStatusId: Number,
    IpAddress: String,
    DateTime: Date,
    UserName: String,
    LoginFrom: String
});

loginSchema.plugin(AutoIncrement, { inc_field: "LoginStatusId" });
var loginModel = mongoose.model("LoginStatus", loginSchema, "LoginStatus");

module.exports = {
  getLoginDetails: function(UserName) {
    return (result = loginModel.findOne({
      $and: [{ UserName: UserName }]
    }));
  },
  validateAdmin: function(request) {
    var authValue = request.headers.authorization;
   
    var credentials = authValue.split(" ")[1];

    var data = credentials.split(":");
    var username = data[0];
    var password = data[1];

    if (username == "Admin" && password == "Admin") {
      return true;
    } else {
      return false;
    }
  },

  // getLocation : function(request,response){
  //   navigator.geolocation.getCurrentPosition(function (err, position) {
  //     if (err) throw err
  //     console.log(position)
  //     response.send(position);
  //   })
  // },

  //Create Login Details
  createLoginDetails: function(request, response) {
    console.log("In create Login Details");
  
    var login = {
    IpAddress:  requestIp.getClientIp(request),
    
      DateTime: new Date(),
      UserName: request.body.UserName,
      LoginFrom:requestIp.getIP
      
  }
    console.log(JSON.stringify(login.IpAddress+"   test ip adress"));
    loginModel.create(login,function(err, res) {
      if (err) {
        console.log("In error");

        console.log(JSON.stringify(err));

        response.statusCode = 500;
        response.send(err);
      }
      if(res){
     // response.send({status:200,data:res});
      console.log("In success");

      console.log(JSON.stringify(res));
      }

    });
  }
};
