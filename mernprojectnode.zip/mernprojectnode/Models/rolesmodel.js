var rolesSchema = mongoose.Schema({
    RoleId:Number,
    RoleName:String
       
    });
    //5c. Map the schema with the collection
                                    //    name    schema        collection
    var rolesModel = mongoose.model("Roles",rolesSchema,"Roles");
    
   
    module.exports={
        createUser:function(request,response){
    
                rolesModel.create(roles,function(err,res){
                    //6b. if error occurred the response error
                    if(err){
                        response.statusCode = 500;
                        response.send({status: response.statusCode,error:err});
                        return;
                    }
                    response.send({status:200,data:res});
         
                     });
               
    
          
            
                    }
                }
       