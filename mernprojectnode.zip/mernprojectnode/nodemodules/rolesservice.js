var mongoose = require("mongoose");

const AutoIncrement = require("mongoose-sequence")(mongoose);

mongoose.Promise = global.Promise;

var rolesSchema = mongoose.Schema({
  RoleId: Number,
  RoleName: String
});

rolesSchema.plugin(AutoIncrement, { inc_field: "RoleId" });
var rolesModel = mongoose.model("Roles", rolesSchema, "Roles");

module.exports = {
  createRole: function(request, response) {
    var roles = {
      RoleName: request.body.RoleName
    };

    rolesModel.create(roles, function(err, res1) {
      if (err) {
        response.statusCode = 500;
        response.send({
          status: response.statusCode,
          error: err,
          message: "Error occurred while creating role"
        });
        return;
      }
      response.send({ status: 200, data: res1 });
    });
  }
};
